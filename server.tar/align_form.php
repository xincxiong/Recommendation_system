<html>
<head>
<title> Automated Model Building Submission Form</title>

<link rel="stylesheet" href="http://bmcc3.cs.gsu.edu/general.css" type="text/css">
</head>
<body bgcolor ="fffffe">

<H1> Automated Model Building from Sequence Submission Form</h1>
<H2> Please enter your information below </h2>
<p>
It will run blastpgp (psi-blast) to generate a sequence profile and 
then use that profile to
find alignments in the pdb dataset.  It will send an email with what it finds 
and the best scoring models in seperate emails as they are built.  It can take several hours to a day to do this so please be patient.
</p><p>
This server will only work on one chain at a time. 
</p>
<br>
Failure to return a significant model is usually due to three causes:
<ul>
<li> There isn't a homolog in the pdb.
<li> There isn't a significant set of sequences in the non-redundant database that psi-blast uses, and the program cannot generate a meaningful profile.
<li> Nucleotide rather than protein sequence.
</ul>
<p> Sometimes this can be ameliorated by careful manual examination of the data, but beware that models built when this is the case are <em>highly speculative</em>
</p>

<p>Fill in the form and then hit "submit".  </p>

<form enctype="multipart/form-data" action="align_submit.php" method="POST">
RETURN EMAIL ADDRESS <input type="text" name="email"> <br>
your name for this job <input type="text" name="title"> <br>
<hr>
<input type="text" name="number_to_report">number to report (default 10)<br>
<input type="text" name="number_to_build">number to build (default 3)<br>
<input type="text" name="significance_cutoff">significance cutoff (default 2)<br>
<hr>
PROTEIN Sequence (FASTA format) <p>
Please Enter a Protein Sequence. It should usually have more kinds of letters
than A,C,T,G. We would prefer that you translate the 
sequence to ensure that the sequence is the one you want to model.  
You may have cloning artefacts that are not part of the 
desired result.  There may be non-coding sequences that are part of the protein.
We also do not want to have to identify which of the six
possible reading frames is the one you need because there is a reasonable
chance we'll pick an incorrect one. 
</p>
<br> <textarea name="align" rows="10" cols="60">
</textarea><br>
<input type="file" name="align" size="50">
<br>
<input type="submit" name="submit">
<hr>
Optional header information is placed in front of the email return.  This is where information like the CASP header would go.
It is fine to leave this blank.
<br>
Header information<br> <textarea name="header" rows="4" cols="60">
</textarea>
<input type="file" name="header" size="50">
<br>



</form>

</body>
</html>
