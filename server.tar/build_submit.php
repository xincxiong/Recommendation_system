<html>
<head>
</head>
<body class="finalize">
<H1> Submission accepted </h1>

<?php
echo '<p> answers will be emailed to ',$_POST['email'],' from builder@snowy.cs.gsu.edu' ;
$xml_filename = sprintf("%d%d%s.xml",getmypid(),time(),'build');
$output = fopen($xml_filename,"w");
start_tag( $output, "model");
add_attribute( $output,"return",$_POST['email']);
add_attribute( $output,"title",$_POST['title']);
finish_tag($output);

if( $_POST['reversed'] == 'True')
{
start_tag( $output,"control");
add_attribute($output,"type","reversed");
immediate_close_tag($output);
}
start_tag( $output,"control");
add_attribute( $output,"type",$_POST['work']);
immediate_close_tag($output);
start_tag( $output,"control");
add_attribute( $output,"type","strip");
immediate_close_tag($output);

	start_tag($output,"align");
	add_attribute( $output,"chain",$_POST['chain']);
	add_attribute( $output,"pdb_code",$_POST['pdb_id']);
	finish_tag($output);
	if( $_FILES['align']['name'] == '')
	{
		put_raw_data( $output,$_POST['align']);
		fputs($output,"\n");
	}
	else
	{
		$input = fopen($_FILES['align']['tmp_name'],"r");
		while( !feof($input) )
		{
			put_raw_data( $output, fgets($input));
		}
		fclose($input);
		
	}
	close_tag($output,"align");

if( $_FILES['header']['name'] != '')
{
	start_tag($output,"header");
	finish_tag($output);
		$input = fopen($_FILES['header']['tmp_name'],"r");
		while( !feof($input) )
		{
			put_raw_data( $output, fgets($input));
		}
		fclose($input);
	close_tag($output,"header");
} else if( $_POST['header'] != '')
{
	start_tag($output,"header");
	finish_tag($output);
		put_raw_data( $output,$_POST['header']);
		fputs($output,"\n");
	close_tag($output,"header");
}


close_tag($output,"model");
fclose($output);

# ok now for the fun
system( sprintf("./rpc_scheduler.py %s > log &", $xml_filename));


function start_tag( $file, $name )
{
	fputs($file, "<");
	fputs($file,$name);
	fputs($file," ");
}
function finish_tag($file)
{
	fputs($file,">\n");
}
function immediate_close_tag( $file)
{
	fputs($file ," />\n");
}
function close_tag($file,$name)
{
	fputs( $file ,"</"); 
	fputs( $file, $name);
	fputs( $file,">\n");
}
function add_attribute($file,$name,$value)
{
	fputs($file,$name);
	fputs($file,"=");
	fputs($file,'"');
	fputs($file,$value);
	fputs($file,'"');
	fputs($file," ");
}
function put_raw_data($file, $stuff)
{
	fputs($file,$stuff);
}
#$anXML =  new XMLWriter();
#$anXML.openURI("file://new.xml");
#$anXML.startElement( "model");
#$anXML.writeAttribute("return", $_POST['email'])
#$anXML.fullEndElement();
#$anXML.endDocument();
?>
</body>
</html>
