#!/usr/bin/python
#
# just takes the input file and sends it off via xmlrpclib to a 
# site which is off of the website.
#
#import of os lets us use system calls
#import of sys lets us access system parameters and stdin
#import of xml.sax lets us use the standard xml parser which is 
# pretty darn good.
import os
import sys
import xml.sax

#print sys.argv[0]
#print sys.argv[1:]

# we're going to sub class the xml parser to handle our specific data
# it will set states and populate data structures that can be queried
# data that are just input files will be created with more or less random names
#

class  content_handler(xml.sax.ContentHandler):
    current_tag = ''
    return_email = ''
    task = ''
    title = ''
    pdb_code = ''
    chain = ''
    working_output = ''
    is_fast = True
    is_stripped = False
    def startElement(me, tag,attrs):
        me.current_tag = tag
        if tag == 'search':
                me.return_email = attrs.getValueByQName('return')
                me.title = attrs.getValueByQName('title')
                me.task = 'search'
        if tag == 'model':
                me.return_email = attrs.getValueByQName('return')
                me.title = attrs.getValueByQName('title')
                me.task = 'model'
# this is a finalized method
# if it were a stage method it would echo output here.
        return
    def get_email(me):
          return me.return_email
    

#below is the standard incantation for xml parsing
# we could just call the standard routine, but this is
# soooo simple that we'll just do it.
handle =   content_handler()
parser = xml.sax.make_parser()
parser.setContentHandler(handle)
# parser will crash iff not called as scheduler.py <some.xml>
#parser.parse(sys.argv[1])
# open sys.argv[1] and read it into memory as a string then parseit.
the_file = open(sys.argv[1],"r")
the_data = the_file.read(-1) # should read it all
the_file.close()

parser.parse(sys.argv[1])


# so now we have the data, Either in a file or in memory

# idiot check for return value
# if there is not an email to return to I won't run
if handle.get_email() == '' :
     exit

# if I don't recognize the job
if handle.task == '' :
     exit

#ok if we're here its pass basic sanity checks and parses as XML
# then we can invoke the xmlrpc server to do the rest
# the xmlrpc server can be outside of the sandbox, and thus is 
# invisible in detail to an outside source.

from xmlrpclib import Server 

jeeves = Server('http://127.0.0.1:8000')

x = 0
if handle.task == 'search':
   try:
     jeeves.align( the_data)
   except:
     x =x   
#if handle.task == 'model':
#     jeeves.build( the_data)

