#!/usr/bin/python

import subprocess
import time
# invoke as 
# cleaner.py >& errors &
# it will clean up as it goes along


x = 0
while( 1==1):
  try:
    rfiles = (subprocess.check_output("ls *xml ", shell=True))
    files = []
    for a in rfiles:
      if a == '\n':
        files.append(' ')
      else:
        files.append( a)
    sfiles = ''.join(files)
#    print sfiles
    files = sfiles.split(' ')
    
    for afile in files:
#      print( afile)
      subprocess.call("./rpc_scheduler.py "+afile, shell=True )
      subprocess.call("rm -f "+afile, shell=True)
  except:
      x = x
      subprocess.call("rm -f errors", shell=True)

  time.sleep(60)
