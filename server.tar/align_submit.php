<html>
<head>

<link rel="stylesheet" href="http://apollo.cs.gsu.edu/~rwh/general.css" type="text/css">
</head>
<body class="finalize">
<H1> Submission accepted </h1>

<?php
echo '<p> answers will be emailed to ',$_POST['email'],' from aligner@apollo.cs.gsu.edu' ;
echo '<p> you may receive email from the script author if an error is detected which may contain information on how to improve the task or in case of a manually implemented restart </p>';
$xml_filename = sprintf("%d%d%s.xml",getmypid(),time(),'build');
$output = fopen($xml_filename,"w");
//fputs( $output,$_SERVER['QUERY_STRING']);
$header_command = false;
if( $_SERVER['QUERY_STRING'] != '')
{
$header_command = true;
// only here if there is stuff in the query string //fputs( $output,$_SERVER['QUERY_STRING']);

$args=explode('&', $_SERVER['QUERY_STRING']);
$i=0;
while( $i < count($args))
{
 //      fputs($output,$args[$i]);
  //     fputs($output,"\n");
	$values = split('=',$args[$i]);

//	fputs($output,$values[0]);
 //      fputs($output,"\n");
//	fputs($output,$values[1]);
 //      fputs($output,"\n");
//	fputs($output,urldecode($values[1]));
 //      fputs($output,"\n");
//	fputs($output,trim(urldecode($values[1]),"\""));
 //      fputs($output,"\n");
	$tag = trim(urldecode($values[0]),"\"");
	$val = trim(urldecode($values[1]),"\"");
	$_POST[$tag] = $val;

       $i += 1;
}

}
if( $_POST['email'] == '') exit;

start_tag( $output, "search");
add_attribute( $output,"return",$_POST['email']);
add_attribute( $output,"title",$_POST['title']);
finish_tag($output);

start_tag( $output,"control");
	add_attribute( $output,"type","report");
if( $_POST['number_to_report'] == '')
	add_attribute( $output,"value",10);
else
	add_attribute( $output,"value",$_POST['number_to_report']);
immediate_close_tag($output);

start_tag( $output,"control");
	add_attribute( $output,"type","cutoff");
if( $_POST['significance_cutoff'] == '')
	add_attribute( $output,"value",2);
else
	add_attribute( $output,"value",$_POST['significance_cutoff']);
immediate_close_tag($output);

start_tag( $output,"control");
	add_attribute( $output,"type","build");
if( $_POST['number_to_build'] == '')
	add_attribute( $output,"value",5);
else
	add_attribute( $output,"value",$_POST['number_to_build']);
immediate_close_tag($output);



	start_tag($output,"sequence");
	finish_tag($output);
	if( $_FILES['align']['name'] == '')
	{
		if( $_POST['align'] == '') exit;
		put_raw_data( $output,$_POST['align']);
		fputs($output,"\n");
	}
	else
	{
		$input = fopen($_FILES['align']['tmp_name'],"r");
		while( !feof($input) )
		{
			put_raw_data( $output, fgets($input));
		}
		fclose($input);
		
	}
	close_tag($output,"sequence");

if( $_FILES['header']['name'] != '')
{
	start_tag($output,"header");
	finish_tag($output);
		$input = fopen($_FILES['header']['tmp_name'],"r");
		while( !feof($input) )
		{
			put_raw_data( $output, fgets($input));
		}
		fclose($input);
	close_tag($output,"header");
} else if( $_POST['header'] != '')
{
	start_tag($output,"header");
	finish_tag($output);
		put_raw_data( $output,$_POST['header']);
		fputs($output,"\n");
	close_tag($output,"header");
}


close_tag($output,"search");
fclose($output);

# ok now for the fun
system( sprintf("/home/rwh/public_html/aligner/rpc_scheduler.py %s > log ", $xml_filename));


function start_tag( $file, $name )
{
	fputs($file, "<");
	fputs($file,$name);
	fputs($file," ");
}
function finish_tag($file)
{
	fputs($file,">\n");
}
function immediate_close_tag( $file)
{
	fputs($file ," />\n");
}
function close_tag($file,$name)
{
	fputs( $file ,"</"); 
	fputs( $file, $name);
	fputs( $file,">\n");
}
function add_attribute($file,$name,$value)
{
	fputs($file,$name);
	fputs($file,"=");
	fputs($file,'"');
	fputs($file,$value);
	fputs($file,'"');
	fputs($file," ");
}
function put_raw_data($file, $stuff)
{
	fputs($file,$stuff);
}
#$anXML =  new XMLWriter();
#$anXML.openURI("file://new.xml");
#$anXML.startElement( "model");
#$anXML.writeAttribute("return", $_POST['email'])
#$anXML.fullEndElement();
#$anXML.endDocument();
?>
</body>
</html>
