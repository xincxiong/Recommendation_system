#!/usr/bin/python
# this is the basic framework for a build server

#
# design assumption is that this will be called from a php script on 
# a web server.  It will work in a specific directory that will be 
# cleaned up when done.
#
# IT ASSUMES that the '.' directory is fine for writing 
#

# global definitions for programs
# these define where the programs are so that 
# they can be changed

BUILD = "distributed_build.py"

SMTP_SERVER = "techie.cs.gsu.edu"
SIGNATURE = "builder@bmcc3.cs.gsu.edu"

#import of os lets us use system calls
#import of sys lets us access system parameters and stdin
#import of xml.sax lets us use the standard xml parser which is 
# pretty darn good.
import os
import sys
import xml.sax

#print sys.argv[0]
#print sys.argv[1:]

# we're going to sub class the xml parser to handle our specific data
# it will set states and populate data structures that can be queried
# data that are just input files will be created with more or less random names
#

class  content_handler(xml.sax.ContentHandler):
    current_tag = ''
    return_email = ''
    task = ''
    title = ''
    pdb_code = ''
    chain = ''
    working_output = ''
    is_fast = True
    is_stripped = False
    def startElement(me, tag,attrs):
        me.current_tag = tag
        if tag == 'model':
                me.return_email = attrs.getValueByQName('return')
                me.title = attrs.getValueByQName('title')
		me.task = BUILD
# this is a finalized method
# if it were a stage method it would echo output here.
        return
    def get_email(me):
          return me.return_email
    

#below is the standard incantation for xml parsing
# we could just call the standard routine, but this is
# soooo simple that we'll just do it.
handle =   content_handler()
parser = xml.sax.make_parser()
parser.setContentHandler(handle)
# parser will crash iff not called as scheduler.py <some.xml>
parser.parse(sys.argv[1])
#parser.parse('build.xml')
#parser.parse(sys.stdin)
#xml.sax.parse('test.xml',handle,None)

# so now we have the data, Either in a file or in memory

# idiot check for return value
# if there is not an email to return to I won't run
if handle.get_email() == '' :
     exit

# if I don't recognize the job
if handle.task == '' :
     exit

i = 1;
while os.path.exists( hex(i)):
    i = i + 1

directory = hex(i)

os.system("mkdir " + directory ) 
os.system("mv " + sys.argv[1] + " " + directory)
os.system("cp " + handle.task + " " + directory)
current_directory = os.getcwd()
os.chdir(directory)
print handle.task + " " + sys.argv[1]
os.system("./"+handle.task + " "+ sys.argv[1] + " > log ")
os.chdir(current_directory)
#os.system( "rm -rf " + directory)
